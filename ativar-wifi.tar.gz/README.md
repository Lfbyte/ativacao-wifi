# Explicações

 Os componentes e scripts possuem como objetivo a ativação da placa _**Wireless**_ e placas **_ETHERNET_** em notebooks do modelo Lenovo Ideapad 3 e Sony Vaio FE15 e FE16, mas a ativação também é possível em outros modelos que estejam apresentando problemas semelhantes.
 
 1) Efetue o clone do repositório
 2) Entre no diretório
 3) Execute com privilégios elevados
 
Caso não consigo ou identifique algum problema / erro ao tentar executar, deixe o problema descrito na sessão de **_ISSUES_**.
